"""Forms used by the sticky notes application."""

from django import forms

from .models import Note


class NoteForm(forms.ModelForm):
    """Model form for creating and updating notes."""

    class Meta:
        model = Note
        fields = ['title', 'content']
