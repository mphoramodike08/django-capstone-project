# Django Capstone Project

## Run with virtual environment
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver

## Run with Docker
docker build -t myproject .
docker run -p 8000:8000 myproject
